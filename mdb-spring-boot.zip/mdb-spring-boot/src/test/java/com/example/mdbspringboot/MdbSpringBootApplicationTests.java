package com.example.mdbspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MdbSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
